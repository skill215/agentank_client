'use strict';
const fs=require('fs'),assert=require('node:assert/strict'),crypto=require('crypto');
const dir=__dirname,root=process.cwd(),hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const read=p=>JSON.parse(fs.readFileSync(p)),plan=read(dir+'/plan.json'),state=read(dir+'/run/state.json');
const mean=a=>a.reduce((x,y)=>x+y,0)/a.length;
function signP(xs){const n=xs.filter(x=>x!==0).length,k=xs.filter(x=>x>0).length;let term=2**-n,p=0;for(let i=0;i<=n;i++){if(i>=k)p+=term;term*= (n-i)/(i+1);}return Math.min(1,p);}
const groups=new Map(),records=[];let exactControls=0,firstGO=0,prefixes=0,actualBombs=0;
for(const j of plan.batches[0].rounds[0].jobs){const file=dir+'/run/jobs/'+j.id+'.result.json',r=read(file),entry=state.jobs.find(x=>x.id===j.id);assert.equal(hash(fs.readFileSync(file)),entry.resultHash);assert.ok(r.integrityPassed&&r.safetyPassed);assert.equal(r.games,1);
 const old=read(root+'/'+j.payload.previousFile);assert.equal(r.eventSeed,old.eventSeed);
 if(!j.payload.enabled){assert.equal(r.signature,old.signature);exactControls++;}
 const m=groups.get(r.index)||{};assert.ok(!m[j.payload.enabled?'on':'off']);m[j.payload.enabled?'on':'off']=r;groups.set(r.index,m);
 const first=r.decisions.find(x=>x.frame===104);assert.ok(first&&first.action===2);if(j.payload.enabled&&first.proposedAction===1&&first.applied)firstGO++;
 assert.ok(r.trace.some(t=>t.frame===108&&t.events.some(e=>e.type==='bomb'&&e.action==='exploded')));actualBombs++;
 records.push({id:j.id,arm:j.payload.enabled?'on':'off',score:r.score,death:r.death,won:r.score===1,survived:r.eventSurvived,evaluations:r.evaluations,opportunities:r.decisions.filter(d=>d.row!==d.incumbent).length,changes:r.changes,reasonCounts:r.decisions.reduce((o,d)=>(o[d.reason]=(o[d.reason]||0)+1,o),{})});
}
assert.equal(groups.size,32);
const pairs=[...groups].sort((a,b)=>a[0]-b[0]).map(([index,{on,off}])=>{
 for(const k of ['candidate','control'])for(const field of ['compactActionStream','compactArguments']){const a=on.row[k][field],b=off.row[k][field];if(field==='compactActionStream')assert.deepEqual(Buffer.from(a,'base64').subarray(0,104),Buffer.from(b,'base64').subarray(0,104));else assert.deepEqual(a.filter(e=>e[0]<104),b.filter(e=>e[0]<104));}prefixes++;
 return {index,eventSeed:on.eventSeed,scoreDelta:on.score-off.score,survivalDelta:Number(on.eventSurvived)-Number(off.eventSurvived),deathDelta:on.death-off.death,actionDifferent:on.signature!==off.signature};
});
const delta=pairs.map(x=>x.scoreDelta),survival=pairs.map(x=>x.survivalDelta),halves=a=>[mean(a.slice(0,16)),mean(a.slice(16))];
const scoreMean=mean(delta),sampleVariance=delta.reduce((s,x)=>s+(x-scoreMean)**2,0)/(delta.length-1);
const se=Math.sqrt(sampleVariance/delta.length);
const localPassed=exactControls===32&&firstGO===32&&mean(survival)>=.5&&signP(survival)<=.05&&halves(survival).every(x=>x>0)&&scoreMean>=.1&&halves(delta).every(x=>x>0);
const arms=Object.fromEntries(['off','on'].map(arm=>{const rows=records.filter(r=>r.arm===arm),evals=rows.reduce((s,r)=>s+r.evaluations,0),opp=rows.reduce((s,r)=>s+r.opportunities,0);return [arm,{games:rows.length,wins:rows.filter(r=>r.won).length,draws:rows.filter(r=>r.score===.5).length,losses:rows.filter(r=>r.score===0).length,meanScore:mean(rows.map(r=>r.score)),survived:rows.filter(r=>r.survived).length,deaths:rows.reduce((s,r)=>s+r.death,0),triggerRate:{numerator:opp,denominator:evals,value:opp/evals},changes:rows.reduce((s,r)=>s+r.changes,0)}];}));
const tests=fs.readFileSync(dir+'/core-tests.txt','utf8');assert.match(tests,/fail 0/);
const production=require(root+'/tools/agentank/diagnostics/native-base-policy-standalone-arena').productionTreeSha256(root);assert.equal(production,plan.batches[0].rounds[0].jobs[0].payload.productionTree);
const summary={batch:'BP414',decisionId:'OPT-D-0002',processId:'OPT-P-001',localPassed,disposition:localPassed?'retain':'reject',productionAdoption:false,productionTree:production,scope:{historicalStates:1,conditionalSeedPairs:32,independentTerrains:0,optimizationRounds:0},checks:{exactControls,firstGO,pairedPrefixes:prefixes,actualBombEvents:actualBombs,completedGames:64,failedJobs:state.jobs.filter(j=>j.status==='FAILED').length,coreTestsPassed:Number(tests.match(/pass (\d+)/)[1])},arms,effects:{scoreMean,scoreHalves:halves(delta),scoreSignP:signP(delta),conditionalScore95ApproxCI:[scoreMean-2.040*se,scoreMean+2.040*se],uncertaintyScope:'Student-t approximation over paired seeds conditional on ONE selected historical state; not population/terrain uncertainty.',survivalMean:mean(survival),survivalHalves:halves(survival),survivalSignP:signP(survival),deathMean:mean(pairs.map(x=>x.deathDelta)),behavioralPairDifference:{numerator:pairs.filter(x=>x.actionDifferent).length,denominator:32}},cost:{attemptedGames:64,completedGames:64,independentUnits:1,executionSeconds:state.used.seconds,analysisSeconds:null},constraints:{safetyPriorityDifferences:'zero by equality guard and candidate boundary tests',remainingMargins:'Full per-row static distances and reasons in each result; no cross-unit aggregate penalty.',independentEvidence:'unknown',targetRuntime:'unknown; diagnostic code allocates and was not benchmarked for production'},limitations:['One reused state and seed cohort, not general quality qualification','Geometry ignores future opponents/projectiles; it is a tie-break only','Diagnostic runtime includes full-state hashing and allocation','No globally lowered safety gates or production source changes'],nextStep:localPassed?'Audit independent data and preregister a child decision with precision and runtime criteria. Do not repeat these 32 seeds for acceptance.':'Preserve evidence, reject current candidate, diagnose failed criterion without adaptive reruns.'};
for(const [name,value]of Object.entries({'summary.json':summary,'pairs.json':pairs,'game-metrics.json':records}))fs.writeFileSync(dir+'/'+name,JSON.stringify(value,null,2)+'\n');
console.log(JSON.stringify(summary,null,2));
